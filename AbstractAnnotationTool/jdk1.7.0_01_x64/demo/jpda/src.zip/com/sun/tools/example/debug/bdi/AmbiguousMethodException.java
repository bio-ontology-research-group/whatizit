/*
 * Copyright (c) 1998, 1999, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

public class AmbiguousMethodException extends Exception
{

    private static final long serialVersionUID = 7793370943251707514L;

    public AmbiguousMethodException()
    {
        super();
    }

    public AmbiguousMethodException(String s)
    {
        super(s);
    }
}
