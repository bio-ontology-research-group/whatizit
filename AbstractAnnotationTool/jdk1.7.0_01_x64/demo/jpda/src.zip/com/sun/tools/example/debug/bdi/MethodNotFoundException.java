/*
 * Copyright (c) 1998, 1999, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

public class MethodNotFoundException extends Exception
{
    private static final long serialVersionUID = -2064968107599632609L;

    public MethodNotFoundException()
    {
        super();
    }

    public MethodNotFoundException(String s)
    {
        super(s);
    }
}
